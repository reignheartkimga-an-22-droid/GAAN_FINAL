import 'package:flutter/material.dart';
import '../controllers/calculator_controller.dart';

class CalculatorView extends StatefulWidget {
  const CalculatorView({super.key});

  @override
  State<CalculatorView> createState() => _CalculatorViewState();
}

class _CalculatorViewState extends State<CalculatorView> {
  final TextEditingController number1Controller = TextEditingController();
  final TextEditingController number2Controller = TextEditingController();

  final CalculatorController controller = CalculatorController();

  String result = "0";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("MVC Calculator")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: number1Controller,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "First Number",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: number2Controller,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "Second Number",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 30),
            Text(
              "Result: $result",
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 30),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      result = controller.calculate(
                        number1Controller.text,
                        number2Controller.text,
                        "add",
                      );
                    });
                  },
                  child: const Text("Add"),
                ),
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      result = controller.calculate(
                        number1Controller.text,
                        number2Controller.text,
                        "subtract",
                      );
                    });
                  },
                  child: const Text("Subtract"),
                ),
              ],
            ),
            const SizedBox(height: 15),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      result = controller.calculate(
                        number1Controller.text,
                        number2Controller.text,
                        "multiply",
                      );
                    });
                  },
                  child: const Text("Multiply"),
                ),
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      result = controller.calculate(
                        number1Controller.text,
                        number2Controller.text,
                        "divide",
                      );
                    });
                  },
                  child: const Text("Divide"),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
