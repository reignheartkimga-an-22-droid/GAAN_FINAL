import '../models/calculator_model.dart';

class CalculatorController {
  final CalculatorModel _model = CalculatorModel();

  String calculate(String input1, String input2, String operation) {
    if (input1.trim().isEmpty || input2.trim().isEmpty) {
      return 'Please enter both numbers.';
    }

    final double? a = double.tryParse(input1.trim());
    final double? b = double.tryParse(input2.trim());

    if (a == null || b == null) {
      return 'Invalid number.';
    }

    double result;
    switch (operation) {
      case 'add':
        result = _model.add(a, b);
        break;
      case 'subtract':
        result = _model.subtract(a, b);
        break;
      case 'multiply':
        result = _model.multiply(a, b);
        break;
      case 'divide':
        if (b == 0) {
          return 'Cannot divide by zero.';
        }
        result = _model.divide(a, b);
        break;
      default:
        return 'Unknown operation.';
    }

    return _format(result);
  }

  String _format(double value) {
    if (value == value.roundToDouble()) {
      return value.toInt().toString();
    }
    return value.toString();
  }
}
