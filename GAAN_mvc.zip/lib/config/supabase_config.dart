/// Supabase project configuration.
///
/// Replace the placeholders with the values from your Supabase dashboard:
/// Project Settings -> API -> Project URL and anon (public) key.
class SupabaseConfig {
  SupabaseConfig._();

  static const String url = 'https://YOUR-PROJECT-REF.supabase.co';
  static const String anonKey = 'YOUR-ANON-PUBLIC-KEY';
}
