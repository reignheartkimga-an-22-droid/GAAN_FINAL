import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart' as sb;

import '../models/user_model.dart';

/// Result of an auth action, so views never touch Supabase directly.
class AuthResult {
  final bool success;
  final String? message;
  final bool needsEmailConfirmation;

  const AuthResult.ok({this.message, this.needsEmailConfirmation = false})
      : success = true;
  const AuthResult.fail(this.message)
      : success = false,
        needsEmailConfirmation = false;
}

/// CONTROLLER: all authentication logic and Supabase communication.
class AuthController extends ChangeNotifier {
  AuthController._();
  static final AuthController instance = AuthController._();

  sb.SupabaseClient get _client => sb.Supabase.instance.client;

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  UserModel? _currentUser;
  UserModel? get currentUser => _currentUser;

  /// Authentication state checking.
  bool get isAuthenticated => _client.auth.currentSession != null;

  /// Stream of auth changes (sign in / sign out / token refresh).
  Stream<sb.AuthState> get authStateChanges => _client.auth.onAuthStateChange;

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  // ---------------------------------------------------------------- Register
  Future<AuthResult> register({
    required String fullName,
    required String email,
    required String password,
    required String confirmPassword,
  }) async {
    final name = fullName.trim();
    final mail = email.trim();

    if (name.isEmpty || mail.isEmpty || password.isEmpty) {
      return const AuthResult.fail('Please fill in all fields.');
    }
    if (!_isValidEmail(mail)) {
      return const AuthResult.fail('Please enter a valid email address.');
    }
    if (password.length < 6) {
      return const AuthResult.fail('Password must be at least 6 characters.');
    }
    if (password != confirmPassword) {
      return const AuthResult.fail('Passwords do not match.');
    }

    _setLoading(true);
    try {
      // full_name goes into user metadata; the DB trigger copies it into
      // public.profiles automatically.
      final response = await _client.auth.signUp(
        email: mail,
        password: password,
        data: {'full_name': name},
      );

      if (response.user == null) {
        return const AuthResult.fail('Registration failed. Please try again.');
      }

      // If email confirmation is ON in Supabase, there is no session yet.
      if (response.session == null) {
        return const AuthResult.ok(
          message: 'Account created! Check your email to confirm, then login.',
          needsEmailConfirmation: true,
        );
      }

      await loadCurrentUser();
      return const AuthResult.ok(message: 'Registration successful!');
    } on sb.AuthException catch (e) {
      return AuthResult.fail(_friendlyError(e));
    } catch (_) {
      return const AuthResult.fail('Something went wrong. Check your connection.');
    } finally {
      _setLoading(false);
    }
  }

  // ------------------------------------------------------------------- Login
  Future<AuthResult> login({
    required String email,
    required String password,
  }) async {
    final mail = email.trim();
    if (mail.isEmpty || password.isEmpty) {
      return const AuthResult.fail('Please enter your email and password.');
    }

    _setLoading(true);
    try {
      await _client.auth.signInWithPassword(email: mail, password: password);
      await loadCurrentUser();
      return const AuthResult.ok();
    } on sb.AuthException catch (e) {
      return AuthResult.fail(_friendlyError(e));
    } catch (_) {
      return const AuthResult.fail('Something went wrong. Check your connection.');
    } finally {
      _setLoading(false);
    }
  }

  // ------------------------------------------------------------------ Logout
  Future<AuthResult> logout() async {
    _setLoading(true);
    try {
      await _client.auth.signOut();
      _currentUser = null;
      return const AuthResult.ok();
    } on sb.AuthException catch (e) {
      return AuthResult.fail(_friendlyError(e));
    } catch (_) {
      return const AuthResult.fail('Could not log out. Please try again.');
    } finally {
      _setLoading(false);
    }
  }

  // ----------------------------------------------------- Authenticated user
  /// Loads the user's profile from `public.profiles`, falling back to the
  /// auth user's metadata if the row is not available.
  Future<UserModel?> loadCurrentUser() async {
    final authUser = _client.auth.currentUser;
    if (authUser == null) {
      _currentUser = null;
      notifyListeners();
      return null;
    }

    try {
      final row = await _client
          .from('profiles')
          .select()
          .eq('id', authUser.id)
          .maybeSingle();
      _currentUser =
          row != null ? UserModel.fromMap(row) : UserModel.fromAuthUser(authUser);
    } catch (_) {
      _currentUser = UserModel.fromAuthUser(authUser);
    }
    notifyListeners();
    return _currentUser;
  }

  // ----------------------------------------------------------------- Helpers
  bool _isValidEmail(String value) =>
      RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(value);

  String _friendlyError(sb.AuthException e) {
    final msg = e.message.toLowerCase();
    if (msg.contains('invalid login credentials')) {
      return 'Invalid email or password.';
    }
    if (msg.contains('already registered') || msg.contains('already exists')) {
      return 'An account with this email already exists.';
    }
    if (msg.contains('email not confirmed')) {
      return 'Please confirm your email before logging in.';
    }
    if (msg.contains('password') && msg.contains('at least')) {
      return 'Password is too short.';
    }
    if (msg.contains('rate limit') || msg.contains('too many')) {
      return 'Too many attempts. Please wait and try again.';
    }
    return e.message;
  }
}
