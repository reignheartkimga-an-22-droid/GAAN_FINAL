import 'package:flutter/material.dart';

import '../controllers/auth_controller.dart';
import 'home_view.dart';
import 'login_view.dart';

/// Decides which screen to show based on the Supabase auth state.
/// Handles "returning to the app while already authenticated": the persisted
/// session is restored by supabase_flutter and routes straight to HomeView.
class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = AuthController.instance;

    return StreamBuilder(
      stream: auth.authStateChanges,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting &&
            !auth.isAuthenticated) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        return auth.isAuthenticated ? const HomeView() : const LoginView();
      },
    );
  }
}
