import 'package:supabase_flutter/supabase_flutter.dart' as sb;

/// MODEL: represents an authenticated user / row in `public.profiles`.
class UserModel {
  final String id;
  final String? fullName;
  final String? email;
  final DateTime? createdAt;

  const UserModel({
    required this.id,
    this.fullName,
    this.email,
    this.createdAt,
  });

  /// Builds a model from a `profiles` table row.
  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      id: map['id'] as String,
      fullName: map['full_name'] as String?,
      email: map['email'] as String?,
      createdAt: map['created_at'] == null
          ? null
          : DateTime.tryParse(map['created_at'] as String),
    );
  }

  /// Fallback: builds a model from the Supabase auth user (metadata).
  factory UserModel.fromAuthUser(sb.User user) {
    return UserModel(
      id: user.id,
      fullName: user.userMetadata?['full_name'] as String?,
      email: user.email,
      createdAt: DateTime.tryParse(user.createdAt),
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'full_name': fullName,
        'email': email,
        'created_at': createdAt?.toIso8601String(),
      };

  /// Name to display, falling back to a generic label.
  String get displayName =>
      (fullName != null && fullName!.trim().isNotEmpty)
          ? fullName!
          : 'Authenticated User';
}
