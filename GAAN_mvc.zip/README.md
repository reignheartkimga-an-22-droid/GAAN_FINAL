# Supabase Auth – Flutter (MVC)

Registration, login, logout, and auth-state handling using Flutter + Supabase.

## Structure

```
lib/
├── main.dart                      # Supabase init + app entry
├── config/supabase_config.dart    # Supabase URL + anon key
├── models/user_model.dart         # MODEL: user/profile data
├── controllers/auth_controller.dart  # CONTROLLER: auth logic + Supabase calls
└── views/                         # VIEW: provided UI wired to the controller
    ├── auth_gate.dart             # Routes by auth state
    ├── login_view.dart
    ├── register_view.dart
    └── home_view.dart
supabase/schema.sql                # SQL script to run in Supabase
```

## Setup

1. In the Supabase SQL Editor, run `supabase/schema.sql`.
2. Open `lib/config/supabase_config.dart` and set your project `url` and `anonKey`
   (Supabase Dashboard -> Project Settings -> API).
3. The `android/` and `ios/` folders are included (INTERNET permission is already set on Android). Run:
   ```
   cd supabase_auth_mvc
   flutter pub get      # also writes android/local.properties + ios/Flutter/Generated.xcconfig
   flutter run
   ```
   **iOS** (macOS + Xcode required): `cd ios && pod install && cd ..`, then `flutter run -d <iphone-or-simulator>`.
   Bundle ID is `com.example.supabaseAuthMvc`; set your Team under Runner -> Signing & Capabilities to run on a real device.
4. If Gradle complains about a missing `gradlew` / wrapper jar, run
   `flutter create --platforms=android .` once. It only adds missing files and
   does not overwrite the existing code. If anything in `ios/` fails to open, run `flutter create --platforms=ios .` the same way.

## Notes

- If **Confirm email** is enabled in Supabase (Authentication -> Providers -> Email),
  registration shows a "check your email" message and the user must confirm before
  logging in. For quick testing you can turn it off.
- The `profiles` row is created by the database trigger from the `full_name` metadata
  sent during sign-up.

## Test checklist

| Scenario | Expected |
|---|---|
| Successful registration | Green message; goes to Dashboard (or login if email confirmation is on) |
| Failed registration (empty fields, bad email, short/mismatched password, existing email) | Red snackbar with reason |
| Successful login | Dashboard shows full name + email |
| Invalid credentials | Red "Invalid email or password." |
| Logout | Returns to Login |
| Reopen app while logged in | Goes straight to Dashboard |
